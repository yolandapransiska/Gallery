<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GalleryController;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Like;
use App\Models\Komentar;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/home', function () {
    return view('home');
});
 Route::get('/register', function () {
     return view('register');
 });
 Route::get('/login', function () {
    return view('login');
});
Route::get('/navbar', function () {
    return view('navbar');
});
Route::get('/beranda', function () {
    $foto = Foto::all();
    return view('beranda', compact('foto'));
});
Route::get('/tambahfoto', function () {
    return view('tambahfoto');
});
Route::get('/album', function () {
    $album = Album::where('UserID', session('user')->UserID)->get();
    return view('album', compact('album'));
});
Route::get('/tambahfoto', function () {
    $album = Album::all();
    return view('tambahfoto', compact('album'));
});

Route::get('/tambahalbum', function () {
    return view('tambahalbum');
});



Route::get('/lhtfoto/{FotoID}', [GalleryController::class, 'liatfoto']);
Route::get('/berilike/{FotoID}', [GalleryController::class, 'like']);
Route::post('/berikomen/{FotoID}', [GalleryController::class, 'komen']);
  

Route::post('/register',[GalleryController::class,'aksiregister']);
Route::post('/login',[GalleryController::class,'aksilogin']);
// Route::post('/tambahalbum',[GalleryController::class,'aksialbum']);


Route::post('/beranda',[GalleryController::class,'unggahfoto']);
Route::post('/tambahfoto',[GalleryController::class,'unggah']);
Route::get('/album{FotoID}', [GalleryController::class,'datafoto']);


Route::post('/album',[GalleryController::class,'aksialbum']);

Route::get('/album{FotoID}', [GalleryController::class,'datafoto']);

Route::get('/tambahalbum', function () {
    return view('tambahalbum');
});
  
Route::post('/like/{FotoID}', [GalleryController::class,'like']);

Route::get('/like', function () {
    return view('like');
});

// Route::get('/lihatfoto/{FotoID}', function ($FotoID)) {
//     $field = Foto::where('FotoID', $FotoID)->first();
//     $field = Komen::where('FotoID', $FotoID)->get();
//     $like = user::All();
//     return view('lihatfoto', compact('field', 'komentar', 'like', 'user'));
// });





