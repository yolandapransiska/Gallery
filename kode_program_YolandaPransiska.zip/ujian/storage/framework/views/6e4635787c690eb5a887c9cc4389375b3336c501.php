<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'poppins', sans-serif;
    }

    body{
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    header{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        padding: 20px 100px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 99;
        background: #B69575;
    }


 .b a {
    position: relative;
    font-size: 1.1em;
    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 15px;
 }

   
.search{
  position:relative;
  justify-content: center;
  border-radius: 25px;
  margin-left: 100px;
  width: 100px;
  height: 42px;
  border: 4px solid white;
  padding:0px 10px;
}

.elements{
  width: 100%;
  height: 100%;
}

.box {
  margin: 9px;
  border: none;
  height: 100%;
  width: 100%;
  padding: 0px 0px;
  border-radius: 15px;
  font-size: 18px;
  font-family: "Poppins";
  background-color: #B69575;
  font-weight: 500;
}

.box:focus{
outline:none;
}

.material-symbols-outlined{
font-size:26;
color: black;
}
</style>

</head>
<body>
<!-- <?php echo e(session('user')->Username); ?> -->
    <header>
    <nav class="b">
    <a href="/home">HOME</a>
    <a href="/album">MY GALLERY</a>
   <a href="/home">LOGOUT</a>

</nav>
<div class="search">
    <table class="elements">
    <td>
    <?php echo e(session('user')->NamaLengkap); ?>

    </td>
      
    </table>   
</div>


    
</header>

</html><?php /**PATH C:\laragon\www\ujian\resources\views/navbar.blade.php ENDPATH**/ ?>