<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <meta http-equiv="X-UA-Compatible" content="ie=edge"> -->
    <title>Document</title>
</head>

<style>

    body {
        background-color: #B69575;
    }
    .see-img{
    margin-top: 5%;
    width: 40%;
    background-color: white;
    border-radius: 10px;
    position: relative;
    transform: translateX(-50%);
    left: 50%;
    box-shadow: 0 0 8px #222;
    overflow: hidden;
   
}
.see-img .fotonya img{
    width: 100%;
    border-radius: 10px;
    box-shadow: 0 0 5px #222;
}
.see-img .like-com{
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    font-family: 'Nunito sans';
    font-weight: bold;
    padding: 2px 9px;
}
.see-img .like-com .btnlk{
    display: flex;
    flex-direction: row;
    font-size: 18px;
    align-items: center;
}
.see-img .like-com .btnlk .like{
    margin-right: 10px;
}
.see-img .like-com .btnlk .like a{
    color: #222;
    text-decoration: none;
}
.see-img .desk-img{
    padding: 2px 9px;
    font-family: 'Nunito sans';
    font-weight: bold;
}
.see-img .kom{
    padding: 2px 9px;
    font-family: 'Nunito sans';
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    margin: 30px 0px;
}
.see-img .create-kom{
    width: 100%;
    padding: 2px 9px;
}
.see-img .create-kom form{
    display: flex;
    flex-direction: row;
    /* justify-content: space-between; */
    width: 100%;
}
.see-img .create-kom .isi-komen{
    width: 90%;
    height: 25px;
    margin: 10px 0px 2px 0px;
    border-radius: 10px;
    border: 1px solid #222;
    padding: 3px 7px;
    font-family: 'Nunito sans';
}
.see-img .create-kom button{
    background-color: none;
    border: transparent;
    cursor: pointer;
}
.see-img .create-kom button i{
    font-size:20px;
    margin-left: 5px;
}
.b a {
    position: relative;
    font-size: 1.1em;
    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 15px;
 }
</style>
<body>

</header>
<header>
    <nav class="b" style="margin-top: 25px;">
        <a href="/beranda" style="margin-top: 20px;">HOME</a>
        <a href="/home" style="margin-top: 20px;">LOG OUT</a>
    </nav>
</header>
    <div class="see-img">
        <div class="fotonya">
            <img src="<?php echo e(Storage::url($foto->LokasiFile)); ?>" alt="...">
        </div>
        
        
        <div class="desk-img">
            <table>
                <tr>
                 <?php if($nama = $user->where('UserID', $user->UserID)->first()): ?><?php echo e($nama->Username); ?>

        <?php endif; ?> 
                    <td>Judul Foto</td>
                    <td>:</td>
                    <td> <?php echo e($foto->JudulFoto); ?></td>
                </tr>
                <tr>
                    <td>Deskripsi Foto</td>
                    <td>:</td>
                    <td><?php echo e($foto->DeskripsiFoto); ?></td>
                </tr>
                
            </table>
        </div>
        <div class="like-com">
            
            <div class="btnlk">
                <div class="like">

                    <?php if($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first()): ?>
                        <a href="/berilike/<?php echo e($foto->FotoID); ?>">
                            <i class="fa-solid fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        <?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?>

                    <?php else: ?>
                        <a href="/berilike/<?php echo e($foto->FotoID); ?>">
                            <i class="fa-regular fa-thumbs-up" style="font-size: 20px"></i>
                        </a>
                        <?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?>

                    <?php endif; ?>  
                </div>
                <div class="komentar">
                    <i class="fa-regular fa-comment" style="font-size: 20px"></i>
                    <?php echo e($komen->count()); ?>

                </div>
            </div>
        </div>
        <hr style="width: 100%; color: black; height: 1px;background-color: black;">
        <?php if($komen == null): ?>
            <div class="kom">
                Belum ada komentar, jadilah pertama yang menanggapi!
            </div>
        <?php else: ?>
            <?php $__currentLoopData = $komen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="kom">
                    <div class="kom-left">
                        <div class="user-com"><i class="fa-solid fa-circle-user"></i>
                            <?php if($namanya = $user2->where('UserID', $kom->UserID)->first()): ?>
                                <?php echo e($namanya->NamaLengkap); ?>

                            <?php endif; ?>
                        </div>
                        <div class="isi-com"><?php echo e($kom->IsiKomentar); ?></div>
                    </div>
                    <div class="tgl-kom">
                        <?php echo e($kom->TanggalKomentar); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="create-kom">
            <form action="/berikomen/<?php echo e($foto->FotoID); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="text" name="isi" placeholder="Masukkan komentar kamu..." required class="isi-komen">
                <button><i class="fa-solid fa-paper-plane"></i></button>
            </form>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/29c53c391a.js" .crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('script/main.js')); ?>"></script>
</body>
</html><?php /**PATH C:\laragon\www\ujian\resources\views/lihatfoto.blade.php ENDPATH**/ ?>