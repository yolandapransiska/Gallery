<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title> 
    <style>

      * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Gill Sans', 'Gill Sans Mt', 'Calibri', 'Trebuchet MS', sans-serif;
      }
body {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: #B69575;  
}
.container {
    width: 100%;
    display: flex;
    max-width:730px;
    background: #fff;
    border-radius: 25px;
    box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
}

.Register{
    width: 250px;
  
}

form {
    width:290px;
    margin: 20px;
}

h1 {
    margin: 20px;
    text-align: center;
    font-weight: bolder;
    text-transform: uppercase;
}

hr {
    border-top: 3px solid #B69575;
}

p{
    text-align: center;
    margin: 10px;
}

.right img {
    width: 430px;
    height: 430px;
    border-top-right-radius: 15px;
    border-bottom-right-radius: 15px;
}

form label{
    display: block;
    font-size: 15px;
    font-weight: 600;
    padding: 5px;
}

input {
    width: 200px;
    margin: 2px;
    border: none;
    outline: none;
    padding: 8px;
    border-radius: 20px;
    border: 1px solid black;
}

.btn {
    width: 100px 
}
 button:hover{
    background: gray;
 }

</style>

</head>

<body>   
    <div class="container">
        <div class="Register">
            <form action="/register" method="POST">
            <?php echo csrf_field(); ?>
                <h1>REGISTER</h1>
                <hr>
                <label for="">Nama</label>
                <input type="text" required name="nama">
            <br>
                <label for="">Email</label>
                <input type="text" placeholder="example@gmail.com" required name="email">
            <br>
                <label for="">Username</label>
                <input type="text" placeholder="username" required name="username">
            <br>
                <label for="">Password</label>
                <input type="password" placeholder="password" required name="password">
            <br>
                <label for="">Alamat</label>
                <input type="text" required name="alamat">
             <br>   
             <br>
                <center>
                    <input class="btn btn-dark rounded-pill px-3" type="submit" value="daftar">
                </center>
                
                </form>
                </div>

            <div class="right">
            <img src="img/register.jpg" alt=""> 
            </div>

    
    </div>
</body>
</html>                                                                                                                                                                                                                                                                                                                 <?php /**PATH C:\laragon\www\ujian\resources\views/register.blade.php ENDPATH**/ ?>