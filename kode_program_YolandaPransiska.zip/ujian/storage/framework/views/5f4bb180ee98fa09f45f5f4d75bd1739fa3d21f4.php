<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title> 
    <style>

      * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Gill Sans', 'Gill Sans Mt', 'Calibri', 'Trebuchet MS', sans-serif;
      }
body {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: #B69575;  
}
.container {
    width: 100%;
    display: flex;
    max-width:600px;
    background: #fff;
    border-radius: 25px;
    box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
}

.Register{
    width: 250px;
  
}

form {
    width:290px;
    margin: 20px;
}

h1 {
    margin: 30px;
    font-weight: bolder;
    text-transform: uppercase;
    margin-right: 35px;

}

hr {
    border-top: 3px solid #B69575;
    width: 450px;
}

p{
    text-align: center;
    margin: 10px;
}

/* gambar */
.right img {
    width: 350px;
    height: 350px;
    border-top-right-radius: 15px;
    border-bottom-right-radius: 15px;
    margin-right: 20px;
}

form label{
    display: block;
    font-size: 15px;
    font-weight: 600;
    padding: 5px;
    margin: 10px;
}

input {
    width: 200px;
    margin: 10px;
    border: none;
    outline: none;
    padding: 8px;
    border-radius: 20px;
    border: 1px solid black;
}

.btn {
    width: 100px 
}
 button:hover{
    background: gray;
 }

</style>

</head>

<body>   
    <div class="container">
        <div class="Register">
            <form action="/login" method="POST">

            <?php echo csrf_field(); ?>
                <h1>LOGIN</h1>
              <?php echo e(session()->get('pesan')); ?> 
                <hr>
                <label for="">Username</label>
                <input type="text"Required name="username" >
        
            <br>
                <label for="">Password</label>
                <input type="password" placeholder="password" Required name="password">
    
             <br>   
             <br>
                <center>
                    <input class="btn btn-dark rounded-pill px-3" type="submit" value="login">
                </center>

                <p>
                    Belum punya akun?<a href="/register">Daftar</a>
                </p>
                
               
                </form>
                </div>

            <div class="right">
            <img src="img/login1.jpg" alt=""> 
            </div>

      
    </div>
</body>
</html><?php /**PATH C:\laragon\www\ujian\resources\views/login.blade.php ENDPATH**/ ?>