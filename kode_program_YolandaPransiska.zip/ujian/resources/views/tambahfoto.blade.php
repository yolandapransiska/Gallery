<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Gallery</title>

    <style>
    body {
        background:  #B69575;
        background-blend-mode: multiply;
        background-position: center;
        background-size: cover;
        display: flex;
        flex-direction: column; 
        min-height: 100vh;
    }
    .row {
        margin-top: 1%  ;   
    }
    .card-body {
        box-shadow: 0 0 10px #000000;
        margin: 20px;
    }
    .b a {
    margin-top: 10px;
    position: relative;
    font-size: 1.1em;
    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 25px;
 }
    </style>
</head>
<body>
<body>
<header>
    <nav class="b" style="margin-top: 25px;">
        <a href="/beranda" style="margin-top: 20px;">HOME</a>
    </nav>
</header>
   
    <section>
        <div class="container mt-3 pt-5">
            <div class="row">
                <div class="col-18 col-sm-12 col-md-9 m-auto">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                        

                        <form action="/beranda" method="POST"class="form"  enctype="multipart/form-data">
                             @csrf
    
                                <input type="text" name="judul" class="form-control my-4 py-2" placeholder=" Judul Foto" Required>
                                <input type="text" name="deskripsi" class="form-control my-4 py-2" placeholder="Deskripsi foto" Required>
                                <input type="file" name="file" class="form-control my-4 py-2" placeholder="Foto" Required>
                                
                                <select class="form-select" name="album">
                                    <option selected>Pilih....</option>
                                @foreach($album as $field)
                                        <option value="{{ $field->AlbumID }}">{{$field->NamaAlbum}}</option>
                                @endforeach
                                </select>
                                <div class="text-center mt-3">   
                                <input type="submit" value="KIRIM" class="btn btn-primary">
                                </div>
                              
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>