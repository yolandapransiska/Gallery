<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
      <title>Gallery</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
      <style>
          body{
            background: #B69575;
          }
          .grid{
            display: grid;
            grid-template-columns: repeat(3,1fr);
            margin: 100px;
            align-items: center;
            grid-gap:  0px;
            background-color: #B69575;
          }
          img{
            object-fit: cover;
          }
          .grid > article{
            box-shadow: 5px 5px  5px 0px black;
            border-radius: 20px;
            text-align: center;
            background: #F5DEB3;
            width: 300px;
            transition: transform;  
          } 
          .grid > article img{
            border-top-left-radius: 30px;
            border-top-right-radius: 30px;
          }
          /* .konten{
            cursor: progress;
          } */ */
          .grid > article:hover{
            /* transform: rotate(15deg); */
            /* transform: sclae(0.5);  zoom out*/
            transform: scale(1.2);
            /* transform: translate(50px); geser */
          }
          header{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        padding: 20px 100px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 99;
        background: #B69575;
    }


 .b a {
    position: relative;
    font-size: 1.1em;
    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 15px;
 }

 .gallery {
   bac
 }
          @media (max-width:1000px){
            .grid{
              grid-template-columns: repeat(2,1fr);
            }
          }
          @media (max-width:800px){
            .grid{
              grid-template-columns: repeat(1.1fr); 
            }
          }
      </style>
<body>
<header>
    <nav class="b">
    <a href="/beranda">HOME</a>
   <a href="/home">LOGOUT</a>
</nav>
<div class="d-flex gap-2 justify-content-center"> 
 <a href="/tambahfoto"> <span class="badge bg-secondary-subtle text-secondary-emphasis rounded-pill">tambah foto +</span></a>
  <a href="/tambahalbum"><span class="badge bg-secondary-subtle text-secondary-emphasis rounded-pill">tambah album +</span></a>
</div>
    
</header>
@foreach($album as $field)
  <div class = "container">
    <main class = "grid">
      <article>
        <!-- <img src = "img/kucing.jpg" width="200"px height="200px">  -->
        
        <div class= "gallery">
          <h2> {{ $field->NamaAlbum}} </h2>
          <p> {{ $field->Deskripsi}} </p>
          <a href="/album{{ $field->AlbumID}}"><span class="badge bg-secondary-subtle text-secondary-emphasis rounded-pill">lihat</span></a>
        </div>
      </article>
        @endforeach
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>