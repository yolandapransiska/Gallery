<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>desk</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        @import url('https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900');

        *
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        body
        {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #944E63;
        }
        .container
        {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 100px 50px;
            padding: 100px 50px;
        }
        .container .card
        {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            width: 350px;
            height: 300px;
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 35px 80px rgba(0,0,0,15);
            transition: 0,5s;
        }
        .container .card:hover
        {
            height: 400px;
        }
        .container .card .imgBx
        {
            position: absolute;
            top: 20px;
            width: 300px;
            height: 220px;
            background: #333;
            border-radius: 12px;
            overflow: hidden;
            transition: 0.5s;
        }
        .container .card:hover .imgBx
        {
            top: -100px;
            scale: 0.75;
            box-shadow: 0 15px 45px rgba(0,0,0,0,.15);
        }
        .container .card .imgBx img
        {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .container .card .content
        {
            position: absolute;
            top: 200px;
            width: 100%;
            padding: 0 30px;
            height: 35px;
            overflow: hidden;
            text-align: center;
            transition: 0.5px;
        }
        .container .card:hover .content
        {
            top: 130px;
            height: 250px;
        }
        .container .card .content h2
        {
            font-size: 1.5em;
            font-weight: 700;
            color: var(--clr);
        }
        .container .card .content p
        {
            color: #333;
        }
        .container .card .content a
        {
            position: relative;
            top: 15px;
            display: inline-block;
            padding: 12px 25px;
            background: var(--clr);
            color: #fff;
            font-weight: 500;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
    <div class="card" style="--clr: #9F70FD;">
    <div  class="imgBx">
        <img src="{{ Storage::url($user->LokasiFile)}}" alt="">
    </div>
    <div class="content">
        <h2>Judul Foto: {{$user->JudulFoto}}</h2>
        <p>Deskripsi Foto: {{$user->DeskripsiFoto}}</p>
        <!-- <a href="#">read more</a> -->
    </div>
</div>
<div class="social">
            <form action="/like/{{$user->FotoID}}" method="post">
            @csrf
            @if ($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $user->FotoID)->first())
            <div class="like-btn-container">
                <button class="btn rounded-pill px-3" style="background: none; border:none;" type="submit"><i class="bi bi-heart-fill big-icon" style="color: red; font-size: 25px; margin-top: 50px; "></i></button>
                {{$like->where('FotoID', $user->FotoID)->count() }}
            @else
                <button class="btn rounded-pill px-3" style="background: none; border:none;" type="submit"><i class="bi bi-heart-fill big-icon" style="color: white; font-size: 25px; margin-top: 50px; "></i></button>
                {{$like->where('FotoID', $user->FotoID)->count()}}
            @endif
            </div>
            <form action="/like/{{$user->FotoID}}" method="post">
            @csrf
            </form>
        </div>

    </div>
</body>
</html>