<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Like;
use App\Models\komentar;
use Carbon\Carbon;

class GalleryController extends Controller
{
    public function index()
    { 
        return view('register');
    } 
    public function aksiregister(Request $request)
    {
        $data = new User();
        $data->Username = $request->input('username');
        $data->Password = $request->input('password');
        $data->Email = $request->input('email');
        $data->NamaLengkap = $request->input('nama');
        $data->Alamat = $request->input('alamat');
        $data->save();

        return redirect('/login');
    }
    public function aksilogin(Request $request)
    {

        $data = User::where('username', $request->input('username'))->where('password', $request->input('password'))->first();
        if($data != null){
            session()->put('user', $data); 
            return redirect('/beranda');
        }else{
            return redirect()->back()->with('pesan','Username / Password Salah');
        }
    }
    public function aksialbum(Request $request)
    {
        
    $data = new Album(); 
    $data->NamaAlbum = $request->input('judul');
    $data->Deskripsi = $request->input('des');
    $data->TanggalDibuat = date ('Y-m-d');
    $data->UserID = session('user')->UserID;
    $data->save();

    return redirect('/album');
    }

    public function unggah(){
        $album = Album::where('UserId', session('user')->UserId)->get();

        return view('tambahfoto', compact('album'));
    }
    public function unggahfoto (Request $request){
        if ($request->hasFile('file')) {

            $locate = $request->file('file')->store('public/image');

            $data = new Foto();
            $data->JudulFoto = $request->input('judul');
            $data->DeskripsiFoto = $request->input('deskripsi');
            $data->TanggalUnggah = date ('Y-m-d');
            $data->LokasiFile = $locate;
            $data->AlbumID = $request->input('album');
            $data->UserID = session('user')->UserID;

            $data->save();
            return redirect('/beranda');
        }
        
    }
    public function datafoto ($AlbumID)
    {
        $album = Album::find($AlbumID);
        $foto = Foto::where('AlbumID', $AlbumID)->get();
        return view('datafoto', compact('album', 'foto'));
    }

   // aksi like
   public function liatfoto($FotoID)
        {
          $foto = Foto::find($FotoID);
          $user = User::find($foto->UserID);
          $user2 = User::all();     
          $like = Like::all();
          $komen = Komentar::where('FotoID', $FotoID)->get();
            return view('lihatfoto', compact('foto','user','like','komen','user2'));

        }
        public function like($FotoID){
            $cek = Like::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first();
            if(!$cek){
                $like = new Like;
                $like->FotoID = $FotoID;
                $like->UserID = session('user')->UserID;
                $like->TanggalLike = Carbon::now();
                $like->save();
                
                return redirect()->back();
            }else{
                $cek->delete();
    
                return redirect()->back();
            }
        }
        public function komen($FotoID, Request $req){
            $komen = new Komentar;
            $komen->FotoID = $FotoID;
            $komen->UserID = session('user')->UserID;
            $komen->IsiKomentar = $req->input('isi');
            $komen->TanggalKomentar = Carbon::now();
            $komen->save();
    
            return redirect()->back();
        }
  
}
                                            